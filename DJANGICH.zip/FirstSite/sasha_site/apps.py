from django.apps import AppConfig


class SashaSiteConfig(AppConfig):
    name = 'sasha_site'
