from django.urls import path

from sasha_site import views

urlpatterns = [
    path('', views.index),
    path('about', views.about),
    path('shop', views.shop)
]